import java.util.Scanner;
public class Administrador  {
  public static void main(String[] args) {
  Scanner sc = new Scanner(System.in);
    private double ajudadecusto;

    public void getCusto() {
      return ajudadecusto;
      ajudadecusto = valor;
    }
    // metodos
    public void inicializarAdministrador(double ajudadecusto){
      custo = ajudadecusto;
    }
    public override void calcularSalario(){
      double SalarioAdministrador = paga = 5000 + custo;
      Sytem.out.println("Salário do Administrador: " + SalarioAdministrador);
    }

  }
}