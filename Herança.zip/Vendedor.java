import java.util.Scanner;
public class Vendedor  {
  public static void main(String[] args) {
  Scanner sc = new Scanner(System.in);
    private double valorVenda, comissao;

    public double getVenda(){
      return valorVenda;
      valorVenda = valor;
    }
    public double getComv(){
      return comissao;
      comissao = valorVenda*35/100;
    }

    public void inicializarVendedor(double valorVenda, double com){
      valorVenda = venda;
      comv = Com;
    }
    public override void calcularSalario(){
      double SalarioVendedor = paga = 5000 + comv;
      System.out.println("Salário do Vendedor: " + SalarioVendedor);
    }

  }
}